#!/usr/bin/env python3
"""
NNLS Deconvolution for Tissue of Origin Analysis
Estimates tissue contributions to cfDNA methylation signal.
"""

import argparse
import numpy as np
import pandas as pd
from scipy.optimize import nnls
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import warnings
warnings.filterwarnings('ignore')


def load_reference_matrix(filepath: str) -> pd.DataFrame:
    """Load reference tissue methylation matrix."""
    df = pd.read_csv(filepath, sep='\t', index_col=0)
    print(f"Loaded reference matrix: {df.shape[0]} markers x {df.shape[1]} tissues")
    return df


def load_sample_methylation(filepath: str, marker_col: str = None) -> pd.Series:
    """Load sample methylation values."""
    df = pd.read_csv(filepath, sep='\t')
    
    # Try to identify the marker and value columns
    if 'region' in df.columns:
        df = df.set_index('region')
    elif 'marker' in df.columns:
        df = df.set_index('marker')
    elif marker_col:
        df = df.set_index(marker_col)
    else:
        # Assume first column is marker, last is value
        df = df.set_index(df.columns[0])
    
    # Get the methylation values (try common column names)
    for col in ['methylation', 'meth', 'beta', 'rms', 'value']:
        if col in df.columns:
            return df[col]
    
    # Use last numeric column
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 0:
        return df[numeric_cols[-1]]
    
    raise ValueError("Could not identify methylation values in sample file")


def scale_data(reference: pd.DataFrame, sample: pd.Series, method: str = 'minmax_by_marker') -> tuple:
    """Scale reference and sample data."""
    
    # Align markers
    common_markers = reference.index.intersection(sample.index)
    print(f"Common markers: {len(common_markers)}")
    
    if len(common_markers) < 10:
        raise ValueError(f"Too few common markers: {len(common_markers)}")
    
    ref_aligned = reference.loc[common_markers]
    sample_aligned = sample.loc[common_markers]
    
    if method == 'minmax_by_marker':
        # Scale each marker independently to [0, 1]
        ref_min = ref_aligned.min(axis=1)
        ref_max = ref_aligned.max(axis=1)
        ref_range = ref_max - ref_min
        ref_range[ref_range == 0] = 1  # Avoid division by zero
        
        ref_scaled = ref_aligned.sub(ref_min, axis=0).div(ref_range, axis=0)
        sample_scaled = (sample_aligned - ref_min) / ref_range
        
    elif method == 'zscore':
        # Z-score normalization
        ref_mean = ref_aligned.mean(axis=1)
        ref_std = ref_aligned.std(axis=1)
        ref_std[ref_std == 0] = 1
        
        ref_scaled = ref_aligned.sub(ref_mean, axis=0).div(ref_std, axis=0)
        sample_scaled = (sample_aligned - ref_mean) / ref_std
        
    elif method == 'none':
        ref_scaled = ref_aligned
        sample_scaled = sample_aligned
        
    else:
        raise ValueError(f"Unknown scaling method: {method}")
    
    return ref_scaled, sample_scaled


def run_nnls(reference: pd.DataFrame, sample: pd.Series) -> dict:
    """
    Run NNLS deconvolution.
    
    Args:
        reference: Reference matrix (markers x tissues)
        sample: Sample methylation values
    
    Returns:
        Dictionary with tissue fractions and residual
    """
    # Convert to numpy
    A = reference.values
    b = sample.values
    
    # Handle any NaN values
    valid_mask = ~(np.isnan(b) | np.any(np.isnan(A), axis=1))
    A = A[valid_mask]
    b = b[valid_mask]
    
    print(f"Running NNLS on {A.shape[0]} markers, {A.shape[1]} tissues")
    
    # Run NNLS
    x, residual = nnls(A, b)
    
    # Normalize to sum to 1
    x_sum = x.sum()
    if x_sum > 0:
        x_normalized = x / x_sum
    else:
        x_normalized = x
    
    # Calculate fit statistics
    predicted = A @ x
    ss_res = np.sum((b - predicted) ** 2)
    ss_tot = np.sum((b - np.mean(b)) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
    
    result = {
        'fractions': dict(zip(reference.columns, x_normalized)),
        'raw_coefficients': dict(zip(reference.columns, x)),
        'residual': residual,
        'r_squared': r_squared,
        'n_markers': len(b)
    }
    
    return result


def run_bootstrap(reference: pd.DataFrame, sample: pd.Series, n_iterations: int = 100) -> dict:
    """Run bootstrap analysis to estimate confidence intervals."""
    
    n_markers = len(sample)
    bootstrap_results = {tissue: [] for tissue in reference.columns}
    
    for i in range(n_iterations):
        # Sample with replacement
        idx = np.random.choice(n_markers, size=n_markers, replace=True)
        ref_boot = reference.iloc[idx]
        sample_boot = sample.iloc[idx]
        
        # Run NNLS
        result = run_nnls(ref_boot, sample_boot)
        
        for tissue, frac in result['fractions'].items():
            bootstrap_results[tissue].append(frac)
    
    # Calculate statistics
    stats = {}
    for tissue, fracs in bootstrap_results.items():
        fracs = np.array(fracs)
        stats[tissue] = {
            'mean': np.mean(fracs),
            'std': np.std(fracs),
            'ci_lower': np.percentile(fracs, 2.5),
            'ci_upper': np.percentile(fracs, 97.5)
        }
    
    return stats


def main():
    parser = argparse.ArgumentParser(description='NNLS Deconvolution for Tissue of Origin')
    parser.add_argument('-s', '--sample', required=True, help='Sample methylation file (TSV)')
    parser.add_argument('-r', '--reference', required=True, help='Reference matrix file (TSV)')
    parser.add_argument('-o', '--output', required=True, help='Output prefix')
    parser.add_argument('--scale', default='minmax_by_marker', 
                       choices=['minmax_by_marker', 'zscore', 'none'],
                       help='Scaling method (default: minmax_by_marker)')
    parser.add_argument('--bootstrap', type=int, default=0,
                       help='Number of bootstrap iterations (0 to disable)')
    parser.add_argument('--marker_col', default=None, help='Column name for markers in sample file')
    
    args = parser.parse_args()
    
    print("=== NNLS Tissue of Origin Deconvolution ===")
    print(f"Sample: {args.sample}")
    print(f"Reference: {args.reference}")
    print(f"Scaling: {args.scale}")
    
    # Load data
    reference = load_reference_matrix(args.reference)
    sample = load_sample_methylation(args.sample, args.marker_col)
    
    # Scale data
    ref_scaled, sample_scaled = scale_data(reference, sample, args.scale)
    
    # Run NNLS
    result = run_nnls(ref_scaled, sample_scaled)
    
    print(f"\nR-squared: {result['r_squared']:.4f}")
    print(f"Residual: {result['residual']:.4f}")
    print(f"\nTissue Fractions:")
    
    # Sort by fraction
    fractions_sorted = sorted(result['fractions'].items(), key=lambda x: x[1], reverse=True)
    for tissue, frac in fractions_sorted:
        print(f"  {tissue}: {frac:.4f} ({frac*100:.2f}%)")
    
    # Save results
    results_df = pd.DataFrame([
        {'tissue': tissue, 'fraction': frac, 'percentage': frac * 100}
        for tissue, frac in fractions_sorted
    ])
    
    output_file = f"{args.output}.tissue_fractions.tsv"
    results_df.to_csv(output_file, sep='\t', index=False)
    print(f"\nResults saved to: {output_file}")
    
    # Save summary
    summary = {
        'sample': args.sample,
        'n_markers': result['n_markers'],
        'r_squared': result['r_squared'],
        'residual': result['residual'],
        'scaling': args.scale
    }
    summary.update({f"frac_{k}": v for k, v in result['fractions'].items()})
    
    summary_df = pd.DataFrame([summary])
    summary_file = f"{args.output}.deconv_summary.tsv"
    summary_df.to_csv(summary_file, sep='\t', index=False)
    print(f"Summary saved to: {summary_file}")
    
    # Run bootstrap if requested
    if args.bootstrap > 0:
        print(f"\nRunning {args.bootstrap} bootstrap iterations...")
        boot_stats = run_bootstrap(ref_scaled, sample_scaled, args.bootstrap)
        
        boot_df = pd.DataFrame([
            {
                'tissue': tissue,
                'mean': stats['mean'],
                'std': stats['std'],
                'ci_lower': stats['ci_lower'],
                'ci_upper': stats['ci_upper']
            }
            for tissue, stats in boot_stats.items()
        ])
        
        boot_file = f"{args.output}.bootstrap_stats.tsv"
        boot_df.to_csv(boot_file, sep='\t', index=False)
        print(f"Bootstrap statistics saved to: {boot_file}")
    
    print("\nDeconvolution complete!")


if __name__ == '__main__':
    main()
